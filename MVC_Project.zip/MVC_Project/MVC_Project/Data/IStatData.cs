﻿using MVC_Project.Models;
using System.Collections.Generic;

namespace MVC_Project.Data
{
    public interface IStatData
    {
        List<Stat> getStats();
    }
}