﻿using MVC_Project.Models;
using System.Collections.Generic;

namespace MVC_Project.Data
{
    public class StatData :IStatData
    {
        public List<Stat> getStats()
        {
            var resultStats = new List<Stat>(); 
            // call dapper to pull stats from a stored procedure
            return resultStats;
        }
    }
}