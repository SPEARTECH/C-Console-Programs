﻿using System;

namespace MVC_Project.Models
{
    public interface IStat
    {
        public DateTime Date { get; set; }

        public double MinutesPlayed { get; set; }
    
        public int GoalsAttempted { get; set; }

        public int GoalsMade { get; set; }
            
    }
}
