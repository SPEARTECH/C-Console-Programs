﻿using System;

namespace MVC_Project.Models
{
    public class Stat : IStat
    {
        public string Date()
        {
            return "2003 - 04 - 16";
        }

        public double MinutesPlayed()
        {
            return 95.67;
        }

        public int GoalsAttempted()
        {
            return 14;
        }


        public int GoalsMade()
        {
            return 15;
        }

        int IStat.GoalsMade { get => throw new NotImplementedException(); set => throw new NotImplementedException(); }
        DateTime IStat.Date { get => throw new NotImplementedException(); set => throw new NotImplementedException(); }
        double IStat.MinutesPlayed { get => throw new NotImplementedException(); set => throw new NotImplementedException(); }
        int IStat.GoalsAttempted { get => throw new NotImplementedException(); set => throw new NotImplementedException(); }
    }
}