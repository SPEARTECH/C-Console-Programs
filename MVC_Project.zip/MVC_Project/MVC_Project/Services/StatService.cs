﻿using MVC_Project.Data;
using MVC_Project.Models;
using System.Collections.Generic;

namespace MVC_Project.Services
{
    public class StatService
    {
        private IStatData _statData;
        public StatService(StatData statData)
        {
            _statData = statData;
        }
        public List<Stat> getStats()
        {
            var resultStats = _statData.getStats();
            
            return resultStats;
        }
    }
}